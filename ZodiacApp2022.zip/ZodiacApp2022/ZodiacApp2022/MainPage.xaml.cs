﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ZodiacApp2022
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

       
        //methods for info pop up about a zodiac sign/////////////////////
        //method repition as i wasn't able to figure a more efficient way to go around this
        private async void infoBtn1_Clicked(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("Aries: Artistic but Mystical!", null, "Back");
        }

        private async void infoBtn2_Clicked(object sender, EventArgs e)
        {
            string action1 = await DisplayActionSheet("Taurus: Caring but a Smart-ass!", null, "Back");
        }

        private async void infoBtn3_Clicked(object sender, EventArgs e)
        {
            string action2 = await DisplayActionSheet("Gemini: Humorous but Arrogant!", null, "Back");
        }

        private async void infoBtn4_Clicked(object sender, EventArgs e)
        {
            string action3 = await DisplayActionSheet("Cancer: Smart but Explosive!", null, "Back");
        }

        private async void infoBtn5_Clicked(object sender, EventArgs e)
        {
            string action4 = await DisplayActionSheet("Leo: Passionate but offending", null, "Back");
        }

        private async void infoBtn6_Clicked(object sender, EventArgs e)
        {
            string action5 = await DisplayActionSheet("Virgo: Creative but Insecure!", null, "Back");
        }

        private async void infoBtn7_Clicked(object sender, EventArgs e)
        {
            string action6 = await DisplayActionSheet("Libra: Funny but Basic!", null, "Back");
        }

        private async void infoBtn8_Clicked(object sender, EventArgs e)
        {
            string action7 = await DisplayActionSheet("Scorpio: Adventurous but Selfish!", null, "Back");
        }

        private async void infoBtn9_Clicked(object sender, EventArgs e)
        {
            string action8 = await DisplayActionSheet("Capricorn: Unique but Unconfident!", null, "Back");
        }

        private async void infoBtn10_Clicked(object sender, EventArgs e)
        {
            string action9 = await DisplayActionSheet("Sagittarius: Loving but Insecure!", null, "Back");
        }

        private async void infoBtn11_Clicked(object sender, EventArgs e)
        {
            string action10 = await DisplayActionSheet("Aquarius: Passionate but Aggresive!", null, "Back");
        }

        private async void infoBtn12_Clicked(object sender, EventArgs e)
        {
            string action11 = await DisplayActionSheet("Pisces: Calm but Confused!", null, "Back");
        }
    }
    ////////////////////////////////////////////////////////////////////////
}
